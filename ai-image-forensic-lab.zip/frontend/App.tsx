
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { AnalysisResultDisplay } from './components/AnalysisResultDisplay';
import { HistorySidebar } from './components/HistorySidebar';
import { analyzeImage } from './services/geminiService';
import { AnalysisResult } from './types';
import { Loader2, AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('forensic_history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('forensic_history', JSON.stringify(history.slice(0, 10)));
  }, [history]);

  const handleImageUpload = useCallback(async (base64Image: string) => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const analysis = await analyzeImage(base64Image);
      setResult(analysis);
      setHistory(prev => [analysis, ...prev]);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze image. Please try again with a different file.");
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const handleSelectHistory = (item: AnalysisResult) => {
    setResult(item);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('forensic_history');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a] text-zinc-100">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8 flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-8">
          <section className="max-w-3xl mx-auto w-full">
            <div className="mb-6 text-center">
              <h2 className="text-3xl font-bold tracking-tight mb-2">Forensic Image Analysis</h2>
              <p className="text-zinc-400">Upload an image to detect AI-generated artifacts and visual inconsistencies.</p>
            </div>

            <ImageUploader onUpload={handleImageUpload} disabled={isAnalyzing} />

            {error && (
              <div className="mt-6 p-4 bg-red-900/20 border border-red-500/50 rounded-xl flex items-center gap-3 text-red-200">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {isAnalyzing && (
              <div className="mt-12 flex flex-col items-center justify-center space-y-4 py-12 border border-zinc-800 rounded-2xl bg-zinc-900/30">
                <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
                <div className="text-center">
                  <p className="text-lg font-medium">Analyzing Visual Data...</p>
                  <p className="text-sm text-zinc-500">Scanning for pixel-level inconsistencies and structural artifacts.</p>
                </div>
              </div>
            )}

            {result && !isAnalyzing && (
              <div className="mt-12">
                <AnalysisResultDisplay result={result} />
              </div>
            )}
          </section>
        </div>

        <aside className="w-full lg:w-80 shrink-0">
          <HistorySidebar 
            history={history} 
            onSelect={handleSelectHistory} 
            onClear={clearHistory}
            activeId={result?.id}
          />
        </aside>
      </main>

      <footer className="py-8 border-t border-zinc-900 text-center text-zinc-600 text-sm">
        <p>© {new Date().getFullYear()} AI Forensic Lab. Powered by Gemini 2.5 Flash.</p>
      </footer>
    </div>
  );
};

export default App;
