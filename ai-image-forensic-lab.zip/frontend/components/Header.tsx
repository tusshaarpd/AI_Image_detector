
import React from 'react';
import { ShieldCheck, Zap } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="border-b border-zinc-900 bg-black/50 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-900/20">
            <ShieldCheck className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tight">Forensic<span className="text-blue-500">Lab</span></h1>
            <p className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-semibold">AI Detection Engine</p>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-400">
          <a href="#" className="hover:text-white transition-colors">Documentation</a>
          <a href="#" className="hover:text-white transition-colors">API</a>
          <div className="h-4 w-[1px] bg-zinc-800"></div>
          <div className="flex items-center gap-2 text-blue-400 bg-blue-400/10 px-3 py-1 rounded-full border border-blue-400/20">
            <Zap className="w-3 h-3" />
            <span className="text-xs">v2.5 Flash Active</span>
          </div>
        </div>
      </div>
    </header>
  );
};
