
import React from 'react';
import { AnalysisResult } from '../types';
import { History, Trash2, ChevronRight, Clock } from 'lucide-react';

interface HistorySidebarProps {
  history: AnalysisResult[];
  onSelect: (item: AnalysisResult) => void;
  onClear: () => void;
  activeId?: string;
}

export const HistorySidebar: React.FC<HistorySidebarProps> = ({ history, onSelect, onClear, activeId }) => {
  const formatTime = (ts: number) => {
    return new Intl.DateTimeFormat('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }).format(ts);
  };

  return (
    <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-full max-h-[800px]">
      <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-zinc-400" />
          <h3 className="font-bold text-sm uppercase tracking-wider">Recent Scans</h3>
        </div>
        {history.length > 0 && (
          <button 
            onClick={onClear}
            className="p-1.5 text-zinc-500 hover:text-red-400 transition-colors"
            title="Clear History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar">
        {history.length === 0 ? (
          <div className="py-12 text-center px-4">
            <Clock className="w-8 h-8 text-zinc-700 mx-auto mb-3" />
            <p className="text-zinc-500 text-sm">No recent scans found.</p>
          </div>
        ) : (
          history.map((item) => (
            <button
              key={item.id}
              onClick={() => onSelect(item)}
              className={`
                w-full flex items-center gap-3 p-2 rounded-xl transition-all text-left group
                ${activeId === item.id ? 'bg-blue-600/20 border border-blue-500/30' : 'hover:bg-zinc-800/50 border border-transparent'}
              `}
            >
              <div className="w-12 h-12 rounded-lg overflow-hidden bg-zinc-800 shrink-0 border border-zinc-700">
                <img src={item.imageUrl} alt="Scan" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className={`text-[10px] font-bold uppercase ${item.isAiGeneratedLikelihood > 50 ? 'text-red-400' : 'text-green-400'}`}>
                    {item.isAiGeneratedLikelihood}% AI
                  </span>
                  <span className="text-[10px] text-zinc-500">{formatTime(item.timestamp)}</span>
                </div>
                <p className="text-xs text-zinc-300 truncate font-medium">{item.verdict}</p>
              </div>
              <ChevronRight className={`w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors ${activeId === item.id ? 'text-blue-400' : ''}`} />
            </button>
          ))
        )}
      </div>

      <div className="p-4 border-t border-zinc-800 bg-zinc-900/50">
        <p className="text-[10px] text-zinc-500 text-center">
          History is stored locally in your browser.
        </p>
      </div>
    </div>
  );
};
