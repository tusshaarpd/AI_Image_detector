
import React from 'react';
import { AnalysisResult, ConfidenceLevel } from '../types';
import { CheckCircle2, AlertTriangle, Info, Fingerprint, Eye, Layers } from 'lucide-react';

interface AnalysisResultDisplayProps {
  result: AnalysisResult;
}

export const AnalysisResultDisplay: React.FC<AnalysisResultDisplayProps> = ({ result }) => {
  const getVerdictColor = (verdict: string) => {
    if (verdict === 'Likely AI') return 'text-red-400 bg-red-400/10 border-red-400/20';
    if (verdict === 'Likely Human') return 'text-green-400 bg-green-400/10 border-green-400/20';
    return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
  };

  const getSeverityColor = (severity: ConfidenceLevel) => {
    switch (severity) {
      case ConfidenceLevel.HIGH: return 'text-red-400';
      case ConfidenceLevel.MEDIUM: return 'text-orange-400';
      case ConfidenceLevel.LOW: return 'text-yellow-400';
      default: return 'text-zinc-400';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 p-8 rounded-2xl bg-zinc-900/50 border border-zinc-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Fingerprint className="w-6 h-6 text-blue-500" />
              <h3 className="text-xl font-bold">Forensic Summary</h3>
            </div>
            <p className="text-zinc-300 leading-relaxed text-lg">
              {result.summary}
            </p>
          </div>
          
          <div className="mt-8 flex flex-wrap gap-4">
            <div className={`px-4 py-2 rounded-full border text-sm font-bold uppercase tracking-wider ${getVerdictColor(result.verdict)}`}>
              Verdict: {result.verdict}
            </div>
            <div className="px-4 py-2 rounded-full border border-zinc-700 bg-zinc-800/50 text-sm font-medium text-zinc-300">
              Confidence: {result.confidenceLevel}
            </div>
          </div>
        </div>

        <div className="p-8 rounded-2xl bg-zinc-900/50 border border-zinc-800 flex flex-col items-center justify-center text-center">
          <div className="relative w-32 h-32 mb-4">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="58"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                className="text-zinc-800"
              />
              <circle
                cx="64"
                cy="64"
                r="58"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={364.4}
                strokeDashoffset={364.4 - (364.4 * result.isAiGeneratedLikelihood) / 100}
                className={`${result.isAiGeneratedLikelihood > 50 ? 'text-red-500' : 'text-green-500'} transition-all duration-1000 ease-out`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold">{result.isAiGeneratedLikelihood}%</span>
              <span className="text-[10px] uppercase text-zinc-500 font-bold">AI Score</span>
            </div>
          </div>
          <p className="text-sm text-zinc-400">Likelihood of synthetic generation</p>
        </div>
      </div>

      {/* Nuances Breakdown */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 px-2">
          <Layers className="w-5 h-5 text-blue-500" />
          <h3 className="text-lg font-bold">Visual Nuances & Artifacts</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {result.nuances.map((nuance, idx) => (
            <div 
              key={idx} 
              className="p-5 rounded-xl bg-zinc-900/30 border border-zinc-800 hover:border-zinc-700 transition-colors group"
            >
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-bold text-zinc-200 group-hover:text-white transition-colors">{nuance.category}</h4>
                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-zinc-800 ${getSeverityColor(nuance.severity)}`}>
                  {nuance.severity} Impact
                </span>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed">
                {nuance.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Technical Details */}
      <div className="p-6 rounded-2xl bg-blue-500/5 border border-blue-500/10">
        <div className="flex items-center gap-3 mb-3">
          <Info className="w-5 h-5 text-blue-400" />
          <h4 className="font-bold text-blue-200">Technical Note</h4>
        </div>
        <p className="text-sm text-blue-200/70 leading-relaxed">
          This analysis is performed using visual pattern recognition and logical consistency checks. While highly accurate at spotting common AI artifacts, it should be used as a supporting tool rather than definitive proof. Modern AI models are rapidly evolving to eliminate these visual "tells."
        </p>
      </div>
    </div>
  );
};
