
import React, { useState, useRef } from 'react';
import { Upload, Camera, Image as ImageIcon, X } from 'lucide-react';

interface ImageUploaderProps {
  onUpload: (base64: string) => void;
  disabled?: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onUpload, disabled }) => {
  const [dragActive, setDragActive] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreview(result);
      onUpload(result);
    };
    reader.readAsDataURL(file);
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const onDragLeave = () => {
    setDragActive(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const clearPreview = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="w-full">
      {!preview ? (
        <div
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          className={`
            relative border-2 border-dashed rounded-2xl p-12 transition-all duration-200
            flex flex-col items-center justify-center text-center cursor-pointer
            ${dragActive ? 'border-blue-500 bg-blue-500/5' : 'border-zinc-800 hover:border-zinc-700 bg-zinc-900/20'}
            ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
          `}
          onClick={() => !disabled && fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/*"
            onChange={onFileChange}
            disabled={disabled}
          />
          
          <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mb-4">
            <Upload className="w-8 h-8 text-zinc-400" />
          </div>
          
          <h3 className="text-xl font-semibold mb-2">Drop image here</h3>
          <p className="text-zinc-500 max-w-xs mx-auto mb-6">
            Support for JPG, PNG, and WebP. Max file size 10MB.
          </p>
          
          <div className="flex gap-3">
            <button 
              type="button"
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
            >
              <ImageIcon className="w-4 h-4" />
              Browse Files
            </button>
            <button 
              type="button"
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
              onClick={(e) => {
                e.stopPropagation();
                // Camera logic would go here
              }}
            >
              <Camera className="w-4 h-4" />
              Use Camera
            </button>
          </div>
        </div>
      ) : (
        <div className="relative rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900/50 group">
          <img 
            src={preview} 
            alt="Preview" 
            className="w-full h-auto max-h-[500px] object-contain mx-auto"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <button 
              onClick={clearPreview}
              className="p-3 bg-red-500 hover:bg-red-600 rounded-full text-white shadow-xl transform hover:scale-110 transition-all"
              disabled={disabled}
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          {disabled && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <div className="flex items-center gap-3 px-6 py-3 bg-zinc-900 rounded-full border border-zinc-700 shadow-2xl">
                <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                <span className="font-medium">Processing...</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
