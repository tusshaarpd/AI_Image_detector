
export enum ConfidenceLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export interface Nuance {
  category: string;
  description: string;
  severity: ConfidenceLevel;
}

export interface AnalysisResult {
  id: string;
  timestamp: number;
  imageUrl: string;
  isAiGeneratedLikelihood: number; // 0-100
  confidenceLevel: ConfidenceLevel;
  nuances: Nuance[];
  summary: string;
  verdict: 'Likely AI' | 'Likely Human' | 'Inconclusive';
}

export interface ScanHistoryItem {
  id: string;
  imageUrl: string;
  timestamp: number;
  likelihood: number;
}
